from abc import ABC, abstractmethod

class Student(ABC):
    id = 0

    def __init__(self, name, gpa):
        self.name = name
        self.gpa = gpa
        self.id = self.setID()

    def setID(self):
        Student.id += 1
        return Student.id

    @abstractmethod
    def complain(self):
        pass

    def __str__(self):
        return (
            f"Name: {self.name}\n"
            f"gpa: {self.gpa}\n"
            f"id: {self.id}"
        )