from schedule import Schedule

class ScheduleProxy:
    def __init__(self):
        self.schedule = Schedule()

    def register(self, course):
        pass

    def display(self):
        pass