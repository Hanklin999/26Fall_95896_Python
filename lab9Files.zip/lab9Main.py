# Main program for Lab 9

students = []

# Problem 1:
# Replace these object creations with calls to the Factory Method class
students.append(...)
students.append(...)

# Problem 2:
# Display each student and their complaint

# Problem 3:
# Create a Schedule object
# Register every student for Python
# Display the schedule

# Problem 4:
# Replace Schedule with ScheduleProxy
# Complete ScheduleProxy so that it logs actions

